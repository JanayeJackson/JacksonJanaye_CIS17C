/* 
 * File:   card.h
 * Author: Janaye Jackson
 *
 * Created on April 19th, 2024, 8:51 PM
 */

#ifndef CARD_H
#define CARD_H

#include <string>

struct card{
    string suit;
    string face;
};



#endif /* CARD_H */

