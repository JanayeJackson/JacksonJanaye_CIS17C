/* 
 * File:   card.h
 * Author: Janaye Jackson
 *
 * Created on April 16th, 2024, 5:16 PM
 */

#ifndef CARD_H
#define CARD_H

#include <string>

struct card{
    string suit;
    string face;
};



#endif /* CARD_H */

